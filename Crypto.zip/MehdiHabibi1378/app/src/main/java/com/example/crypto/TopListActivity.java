package com.example.crypto;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class TopListActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_top_list);
    }
}